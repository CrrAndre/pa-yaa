// Archivo movido para organización. El contenido original permanece igual.
